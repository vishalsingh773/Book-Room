package com.example.bookhub2.booklist

data class DataOfBook (
   var book_id:String,
   var book_name:String,
   var author_name:String,
   var book_price:String,
   var rating:String,
   var bookImage:String){
}